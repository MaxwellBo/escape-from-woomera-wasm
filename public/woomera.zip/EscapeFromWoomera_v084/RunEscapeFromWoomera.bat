..\hl -game EscapeFromWoomera_v084 +map efw_prototype_level1
